<?php 
include "header.php";
?>
	<div class="sidebar">
		<div class="sidebar_inner">
		<ul>
			<li>
				<a href="#">
					<span class="icon"><i class="fas fa-fw fa-tachometer-alt"></i></span>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="#">
					<span class="icon"><i class="fas fa-times-circle"></i></span>
					<span class="text">Logout</span>
				</a>
			</li>
			<li>
				<a href="#">
					<span class="icon"><i class=""></i></span>
					<span class="text"></span>
				</a>
			</li>
			<li>
				<a href="#">
					<span class="icon"><i class=""></i></span>
					<span class="text"></span>
				</a>
			</li>
			<li>
				<a href="#">
					<span class="icon"><i class=""></i></span>
					<span class="text"></span>
				</a>
			</li>
		</ul>
		</div>
	</div>

	<div class="main_container">
		<div class="container">
			
		</div>
	</div>
</div>
<script src="Admin.js"></script>

</body>
</html>